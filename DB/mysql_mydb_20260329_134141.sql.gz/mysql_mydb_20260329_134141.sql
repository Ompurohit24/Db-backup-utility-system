-- MySQL backup of `mydb`
-- Generated: 2026-03-29T13:41:41.855415+00:00
-- -----------------------------------------------------

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `employees`;
CREATE TABLE `employees` (
  `emp_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `join_date` date DEFAULT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (1, 'Amit Sharma', 'amit.sharma@gmail.com', 'IT', '55000.00', '2022-01-15');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (2, 'Neha Verma', 'neha.verma@gmail.com', 'HR', '45000.00', '2021-03-20');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (3, 'Rohit Singh', 'rohit.singh@gmail.com', 'Finance', '60000.00', '2020-07-10');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (4, 'Priya Patel', 'priya.patel@gmail.com', 'Marketing', '50000.00', '2022-05-25');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (5, 'Ankit Gupta', 'ankit.gupta@gmail.com', 'IT', '70000.00', '2019-11-30');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (6, 'Sneha Joshi', 'sneha.joshi@gmail.com', 'HR', '48000.00', '2023-02-14');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (7, 'Vikas Mehta', 'vikas.mehta@gmail.com', 'Finance', '62000.00', '2021-08-18');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (8, 'Pooja Desai', 'pooja.desai@gmail.com', 'Marketing', '51000.00', '2020-12-01');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (9, 'Rahul Nair', 'rahul.nair@gmail.com', 'IT', '68000.00', '2019-06-22');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (10, 'Kavita Rao', 'kavita.rao@gmail.com', 'HR', '47000.00', '2023-04-05');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (11, 'Suresh Kumar', 'suresh.kumar@gmail.com', 'Finance', '63000.00', '2022-09-09');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (12, 'Meena Iyer', 'meena.iyer@gmail.com', 'Marketing', '52000.00', '2021-10-11');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (13, 'Ajay Yadav', 'ajay.yadav@gmail.com', 'IT', '72000.00', '2020-03-17');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (14, 'Ritu Kapoor', 'ritu.kapoor@gmail.com', 'HR', '46000.00', '2019-08-25');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (15, 'Deepak Mishra', 'deepak.mishra@gmail.com', 'Finance', '64000.00', '2023-01-19');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (16, 'Shalini Saxena', 'shalini.saxena@gmail.com', 'Marketing', '53000.00', '2022-07-23');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (17, 'Karan Malhotra', 'karan.malhotra@gmail.com', 'IT', '75000.00', '2021-11-30');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (18, 'Anjali Choudhary', 'anjali.choudhary@gmail.com', 'HR', '49000.00', '2020-06-14');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (19, 'Nikhil Jain', 'nikhil.jain@gmail.com', 'Finance', '65000.00', '2019-02-27');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (20, 'Divya Agarwal', 'divya.agarwal@gmail.com', 'Marketing', '54000.00', '2023-05-01');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (21, 'Manish Tiwari', 'manish.tiwari@gmail.com', 'IT', '71000.00', '2022-08-16');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (22, 'Swati Bhatt', 'swati.bhatt@gmail.com', 'HR', '45500.00', '2021-09-29');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (23, 'Harsh Vardhan', 'harsh.vardhan@gmail.com', 'Finance', '66000.00', '2020-01-12');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (24, 'Preeti Sinha', 'preeti.sinha@gmail.com', 'Marketing', '55000.00', '2019-04-21');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (25, 'Yash Thakur', 'yash.thakur@gmail.com', 'IT', '73000.00', '2023-03-11');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (26, 'Komal Arora', 'komal.arora@gmail.com', 'HR', '47000.00', '2022-06-06');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (27, 'Arjun Reddy', 'arjun.reddy@gmail.com', 'Finance', '67000.00', '2021-12-19');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (28, 'Simran Kaur', 'simran.kaur@gmail.com', 'Marketing', '56000.00', '2020-10-08');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (29, 'Aditya Kulkarni', 'aditya.k@gmail.com', 'IT', '74000.00', '2019-07-07');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (30, 'Neelam Singh', 'neelam.singh@gmail.com', 'HR', '48000.00', '2023-02-28');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (31, 'Gaurav Bansal', 'gaurav.b@gmail.com', 'Finance', '68000.00', '2022-11-03');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (32, 'Tanya Mehra', 'tanya.mehra@gmail.com', 'Marketing', '57000.00', '2021-01-15');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (33, 'Rakesh Pandey', 'rakesh.p@gmail.com', 'IT', '76000.00', '2020-09-09');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (34, 'Pallavi Joshi', 'pallavi.j@gmail.com', 'HR', '49000.00', '2019-05-18');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (35, 'Abhishek Das', 'abhishek.d@gmail.com', 'Finance', '69000.00', '2023-06-20');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (36, 'Isha Shah', 'isha.shah@gmail.com', 'Marketing', '58000.00', '2022-02-12');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (37, 'Varun Kapoor', 'varun.k@gmail.com', 'IT', '77000.00', '2021-04-27');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (38, 'Riya Sen', 'riya.sen@gmail.com', 'HR', '50000.00', '2020-08-30');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (39, 'Mohit Arora', 'mohit.a@gmail.com', 'Finance', '70000.00', '2019-03-03');
INSERT INTO `employees` (`emp_id`, `name`, `email`, `department`, `salary`, `join_date`) VALUES (40, 'Aisha Khan', 'aisha.khan@gmail.com', 'Marketing', '59000.00', '2023-07-14');

SET FOREIGN_KEY_CHECKS=1;
